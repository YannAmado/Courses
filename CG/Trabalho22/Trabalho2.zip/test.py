import pywavefront
obj = pywavefront.Wavefront('chunnin/chunnin.obj')
import pywavefront
from pywavefront import visualization

obj = pywavefront.Wavefront('chunnin/chunnin.obj')
visualization.draw(obj)