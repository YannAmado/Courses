
public class Pessoa {
	
	private String nome;
	private String endereco;
	private String email;
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String newNome) {
		nome = newNome;
	}
	
	public String getEndereco() {
		return endereco;
	}
	
	public void setEndereco(String newEndereco) {
		endereco = newEndereco;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String newEmail) {
		email = newEmail;
	}

	
}
